using namespace std;

#include <iostream>
#include <cstring>

#include "videogames.h"

videogames::videogames() {
  publisher = new char[50];
  rating = 0;

}

char* videogames::getPublisher() {
  return publisher;
}

int videogames::getRating() {
  return rating;
}
