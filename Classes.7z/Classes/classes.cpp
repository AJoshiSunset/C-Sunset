using namespace std;

#include <iostream>
#include <cstring>
#include <vector>

#include "media.h"

void addMedia(vector<media*> & v)
{
  char mediaType[50];

  while (1 == 1)
    {
  
      cout << "Would you like to add a 'videogame', 'movie', or 'music'?" << endl;
  
      cin.get(mediaType, 50);
      cin.get();

      if (mediaType == "videogame")
	{
	  videogames* vi = new videogames();

	  cout << "Title:" << endl;
	  cin >> vi->title;

	  cout << "Year:" << endl;
	  cin >> vi->year;
	  
	  cout << "Publisher:" << endl;
	  cin >> vi->publisher;
	  
	  cout << "Rating:" << endl;
	  cin >> vi->rating;

	  v.push_back(vi);
	  
	  break;
	}
      else if (mediaType == "movie")
	{
	  movies* mo = new movies();
	  
	  cout << "Title:" << endl;
	  mo->title;

	  cout << "Year:" << endl;
	  mo->year;
	  
	  cout << "Director:" << endl;
	  mo->director;

	  cout << "Duration:" << endl;
	  mo->duration;

	  cout << "Rating:" << endl;
	  mo->rating;

	  v.push_back(mo);

	  break;
	}
      else if (mediaType == "music")
	{

	  music* mu = new music();

	  cout << "Title:" << endl;
	  cin >> mu->title;

	  cout << "Year:" << endl;
	  cin >> mu->year;

	  cout << "Artist:" << endl;
	  cin >> mu->artist;

	  cout << "Duration:" << endl;
	  cin >> mu->duration;

	  cout << "Puublisher:" << endl;
	  cin >> mu->publisher;

	  v.push_back(mu);
	  
	  break;
	} 
      else
	{
	  cout << "Invalid Input!" << endl;
	  continue;
	}
  
    }

  
  
    }
  

int main() {

  vector<media*> vec;
  char input[50];
  
  cout << "Would you like to 'add', 'search', or 'delete'?" << endl;

  while (1 == 1) {
    cin.get(input, 50);
    cin.get();

    if (input == "add")
      {
	addMedia(vec);
      }
    else if (input == "search")
      {

      }
    else if (input == "delete")
      {

      }
    else
      {
	cout << "Invalid input!" << endl;
	continue;
      }

    }
  
  
  
  /*
  media* m = new media();

  cin >> m->title;

  vec.push_back(m);
  
  cout << vec[0]->title << endl;
  */
  
  return 0;
}
