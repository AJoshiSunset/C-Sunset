using namespace std;

#ifndef MEDIA
#define MEDIA

#include <iostream>
#include <cstring>

class media {
 public:
  media();
  char* getTitle();
  
  char* title;

  int getYear();
  
  int year;
  
};

#endif


