using namespace std;

#include <iostream>
#include <cstring>

#include "media.h"

class music {
 public:
  music();
  char* getArtist();

  char* artist;

  int getDuration();

  int duration;

  char* getPublisher();

  char* publisher;

};
