using namespace std;

#include <iostream>
#include <cstring>
#include <vector>

#include "media.h"
#include "videogames.h"
#include "movies.h"
#include "music.h"

void addMedia(vector<media*> & v)
{
  char mediaType[50];

  while (1 == 1)
    {
  
      cout << "Would you like to add a 'videogame', 'movie', or 'music'?" << endl;

      cin >> mediaType;
      //cin.get(mediaType, 50);
      //cin.get();

      if (strcmp(mediaType, "videogame") == 0)
	{
	  //vector<videogames*> vi;
	  videogames* vi = new videogames();

	  cout << "Title:" << endl;
	  cin >> vi->title;
	 
	  cout << "Year:" << endl;
	  cin >> vi->year;

	  cin.ignore();
	  cout << "Publisher:" << endl;
	  cin >> vi->publisher;

	  cout << "Rating:" << endl;
	  cin >> vi->rating;

	  v.push_back(vi);
	  
	  cin.clear();
	  cin.ignore(1000, '\n');
	  break;
	  
	}
      else if (strcmp(mediaType, "movie") == 0)
	{
	  //vector<movies*> mo;
	  movies* mo = new movies();
	  
	  cout << "Title:" << endl;
	  cin >> mo->title;

	  cout << "Year:" << endl;
	  cin >> mo->year;
	  
	  cout << "Director:" << endl;
	  cin >> mo->director;

	  cout << "Duration:" << endl;
	  cin >> mo->duration;

	  cout << "Rating:" << endl;
	  cin >> mo->rating;

	  v.push_back(mo);

	  break;
	}
      else if (strcmp(mediaType, "music") == 0)
	{
	  //vector<music*> mu;
	  music* mu = new music();

	  cout << "Title:" << endl;
	  cin >> mu->title;

	  cout << "Year:" << endl;
	  cin >> mu->year;

	  cout << "Artist:" << endl;
	  cin >> mu->artist;

	  cout << "Duration:" << endl;
	  cin >> mu->duration;

	  cout << "Puublisher:" << endl;
	  cin >> mu->publisher;

	  v.push_back(mu);
	  
	  break;
	} 
      else
	{
	  cout << "Invalid Input!" << endl;
	  cin.clear();
	  cin.ignore(1000, '\n');
	  continue;
	}

      break;
    }

  
  
    }

void printMedia(vector<media*> & v, int k) {
  cout << v[k]->title << endl;
}

void searchMedia(vector<media*> & v) {

  char TorY[50];

  while (1 == 1) {
  cout << "Search by 'title' or 'year'?" << endl;

  cin.get(TorY, 50);
  cin.get();

  if (!(strcmp(TorY, "title") == 0 || strcmp(TorY, "year") == 0))
    {
      cout << "Invalid input!" << endl;
      cin.clear();
      cin.ignore(1000, '\n');
      continue;
    }
  break;

    }
  
  char input[50];

  cout << "What is the " << TorY << "?" << endl;

  cin.get(input, 50);
  cin.get();

  for (int i = 0; i < v.size(); i++)
    {
      if (strcmp(v[i]->title, input) == 0) {
	printMedia(v, i);
	
      }
    }
  
}


int main() {

  vector<media*> vec;
  char input[50];

  while (1 == 1) {
    
    cout << "Would you like to 'add', 'search', or 'delete'?" << endl;

    cin.get(input, 50);
    cin.get();

    if (strcmp(input, "add") == 0)
      {
	addMedia(vec);
	continue;
      }
    else if (strcmp(input, "search") == 0)
      {
	searchMedia(vec);
	continue;
      }
    else if (strcmp(input, "delete") == 0)
      {

      }
    else
      {
	cout << "Invalid input!" << endl;
	cin.clear();
	cin.ignore(1000, '\n');
	continue;
      }

    }
  
  
  
  /*
  media* m = new media();

  cin >> m->title;

  vec.push_back(m);
  
  cout << vec[0]->title << endl;
  */
  
  return 0;
}
