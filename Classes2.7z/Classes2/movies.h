using namespace std;

#include <iostream>
#include <cstring>

#include "media.h"

class movies: public media {
 public:
  movies();
  char* getDirector();

  char* director;

  int getDuration();

  int duration;

  int getRating();

  int rating;

};
