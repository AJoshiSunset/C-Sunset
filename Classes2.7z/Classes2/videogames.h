using namespace std; 

#include <iostream> 
#include <cstring> 

#include "media.h"

class videogames: public media {
 public:
  videogames();
  char* getPublisher();

  char* publisher;

  int getRating();

  int rating;

};
