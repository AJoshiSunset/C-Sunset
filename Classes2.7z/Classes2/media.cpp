using namespace std;

#include <iostream>
#include <cstring>

#include "media.h"

media::media() {
  title = new char[50];
  year = 0;
}

char* media::getTitle() {
  return title;
}

int media::getYear() {
  return year;
}


