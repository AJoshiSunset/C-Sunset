using namespace std;

#include <iostream>
#include <cstring>

#include "music.h"

music::music() {
  artist = new char[50];
  duration = 0;
  publisher = new char[50];
}

char* music::getArtist() {
  return artist;
}

int music::getDuration() {
  return duration;
}

char* music::getPublisher() {
  return publisher;
}
